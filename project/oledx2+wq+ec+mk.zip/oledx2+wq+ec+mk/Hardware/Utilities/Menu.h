#ifndef __Menu_H
#define __Menu_H

#include "oled.h"
#include "bmp.h"
#include "oled_92.h"
void Menu1(void);
void Menu2(void);
void Menu3(void);
void Menu4(void);
void Menu5(void);
void Menu6(void);
void Menu7(void);
void Menu8(void);
void Menu9(void);
void Menu10(void);
#endif