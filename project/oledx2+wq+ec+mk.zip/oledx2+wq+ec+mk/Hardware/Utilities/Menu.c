#include "Menu.h"
void Menu1(void) {
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,0);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,1);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,2);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,3);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,4);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,5);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,6);
    OLED_42_ShowPicture(0,0,29,27,BMP2,1,7);
    OLED_42_ShowPicture(0,0,70,22,BMP3,1,8);
    OLED_42_ShowPicture(0,0,70,27,BMP4,1,9);
		OLED_92_ShowPicture(20,1,70,22,BMP5,1,3);
		OLED_92_ShowPicture(20,1,29,22,BMP2,1,4);
    OLED_42_ShowPicture(0,0,70,22,BMP5,1,10);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,11);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,12);
    OLED_42_ShowPicture(2,3,70,22,BMP3,1,13);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,14);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,15);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,16);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,17);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,18);
    OLED_42_ShowPicture(2,3,29,27,BMP2,1,19);
	 
		OLED_92_ShowPicture(20,1,70,22,BMP3,1,0);
		OLED_92_ShowPicture(20,1,29,32,BMP2,1,1);
		OLED_92_ShowPicture(20,1,70,27,BMP4,1,2);
	
}
void Menu2(void) {
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,0);
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,1);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,2);
    OLED_42_ShowPicture(0,0,70,27,BMP4,1,3);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,4);
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,5);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,6);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,7);
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,8);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,9);
	  OLED_92_ShowPicture(20,1,70,22,BMP1,1,0);
		OLED_92_ShowPicture(20,1,29,32,BMP3,1,1);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,10);
    OLED_42_ShowPicture(0,0,70,22,BMP3,1,11);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,12);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,13);
    OLED_42_ShowPicture(0,0,70,22,BMP3,1,14);
    OLED_42_ShowPicture(2,3,70,22,BMP5,1,15);
    OLED_42_ShowPicture(0,0,72,40,BMP1,1,16);
    OLED_42_ShowPicture(0,0,70,27,BMP4,1,17);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,18);
    OLED_42_ShowPicture(20,1,29,32,BMP2,1,19);
	  
		
		
		OLED_92_ShowPicture(20,1,70,27,BMP2,1,2);
		OLED_92_ShowPicture(20,1,70,22,BMP4,1,3);
		OLED_92_ShowPicture(20,1,29,22,BMP5,1,4);
	
}